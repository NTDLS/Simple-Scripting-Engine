# Html-Help-Decompiler
Decompile / walk and evaluate an HTML compiled help file.
