using System;
using System.Collections.Generic;
using System.Text;

namespace Fireball.Drawing.Design
{
    public enum ColorSliderMode
    {
        Hue = 0, Saturation = 1, Luminance = 2
    }
}
