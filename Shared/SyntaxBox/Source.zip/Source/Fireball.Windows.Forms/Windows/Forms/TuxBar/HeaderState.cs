﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Fireball.Windows.Forms.TuxBar
{
	public enum HeaderState
	{
		Expanded = 0,
		Collapsed = 1
	}
}
